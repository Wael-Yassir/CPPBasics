#pragma once

double add(double x, double y);
double add(double a, double b, double c);

bool test(bool x);
bool test(double x);